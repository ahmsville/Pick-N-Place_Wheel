>>>Required steel ball sizes and quantity.

6810 = 3mm steel balls (8pcs)
16001 = 3mm steel balls (6pcs)
16004 = 4.5mm steel balls (7pcs)
6815 = 3mm steel balls (10pcs)
16003 = 3.5mm steel balls (7pcs)
16007 = 4.5mm steel balls (8pcs)