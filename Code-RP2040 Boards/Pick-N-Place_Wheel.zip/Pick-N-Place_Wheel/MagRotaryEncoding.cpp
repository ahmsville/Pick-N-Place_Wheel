#include "MagRotaryEncoding.h"
#include <iostream>
/*
This library was written based on the rotation detection method described @ ""
This library also features a haptics controller, that allows you to connect and control a vibration motor as a step count haptic feedback.

....Written By Ahmed Oyenuga (Ahmsville 2019).
*/

#define RISING 0x08
#define FALLING 0x04
volatile bool sleepmode = false;

bool MagRotaryEncoder::passSynctest(int newspos)
{
	if (encoderResolution > 0)
	{
		if (startposition == 1)
		{
			if (newspos == 4 || newspos == 2)
			{
				return true;
			}
		}
		else if (startposition == 2)
		{
			if (newspos == 1 || newspos == 3)
			{
				return true;
			}
		}
		else if (startposition == 3)
		{
			if (newspos == 2 || newspos == 4)
			{
				return true;
			}
		}
		else if (startposition == 4)
		{
			if (newspos == 3 || newspos == 1)
			{
				return true;
			}
		}
		return false;
	}
	else
	{
		return true;
	}
}

bool MagRotaryEncoder::debouncePin(int pin)
{

	int pinindex = 0;
	for (size_t i = 0; i < 4; i++)
	{
		if (SensorINTpin[i] == pin)
		{
			pinindex = i;
			i = 4;
		}
	}
	absolute_time_t nowtime = get_absolute_time();
	//printf("to boot %d \n",to_us_since_boot(nowtime) - to_us_since_boot(intFiredTime[pinindex]));
	int diff = absolute_time_diff_us(intFiredTime[pinindex], nowtime);

	if (diff > debounce)
	{
		intFiredTime[pinindex] = nowtime;
		//printf(" \n");
		printf("pin %d \n", pin);
		printf("time diff %d \n", diff);
		printf("passed \n");

		return true;
	}
	else
	{
		intFiredTime[pinindex] = nowtime;
		//printf("Failed \n");
		return false;
	}
}
bool MagRotaryEncoder::XOR_INTPins()
{
	int onpincnt = 0;
	for (size_t i = 0; i < 4; i++)
	{
		if (gpio_get(SensorINTpin[i]) == 1)
		{
			onpincnt += 1;
		}
	}
	if (onpincnt == 1)
	{
		return true;
	}
	else
	{
		return false;
	}
}
int MagRotaryEncoder::singleISR(int pin)
{

	int activepos = 0;
	if (SensorINTpin[2] == pin)
	{
		activepos = 1;
		//get pos
		if (gpio_get(pin) && is_nil_time(Pos_1_pulse[0]) && !Pos_1_pulsesaved)
		{ //set time of rise once
			Pos_1_pulse[0] = get_absolute_time();
		}
		else if (gpio_get(pin) == 0 && !is_nil_time(Pos_1_pulse[0]))
		{ //set time of fall if time of rise as already been set
			Pos_1_pulse[1] = get_absolute_time();
			int diff = absolute_time_diff_us(Pos_1_pulse[0], Pos_1_pulse[1]);
			if (diff > debounce)
			{
				//save pulse
				Pos_1_pulsesaved = true;
				Pos_2_pulsesaved = false;
				//Pos_3_pulsesaved = false;
				Pos_4_pulsesaved = false;

				Pos_1_scheduleslot = scheduleslotcounter;
				scheduleslotcounter += 1;
				printf("Pos_1 risetime %d \n", to_ms_since_boot(Pos_1_pulse[0]));
				printf("Pos_1 pulse diff %d scheduled slot %d \n", diff, Pos_1_scheduleslot);
			}
			else
			{
				Pos_1_pulsesaved = false;
				//printf("debounced \n");
			}
			Pos_1_pulse[0] = nil_time;
		}
	}
	else if (SensorINTpin[1] == pin)
	{
		activepos = 2;
		//get pos
		if (gpio_get(pin) && is_nil_time(Pos_2_pulse[0]) && !Pos_2_pulsesaved)
		{ //set time of rise once
			Pos_2_pulse[0] = get_absolute_time();
		}
		else if (gpio_get(pin) == 0 && !is_nil_time(Pos_2_pulse[0]))
		{ //set time of fall if time of rise as already been set
			Pos_2_pulse[1] = get_absolute_time();
			int diff = absolute_time_diff_us(Pos_2_pulse[0], Pos_2_pulse[1]);
			if (diff > debounce)
			{
				//save pulse
				Pos_2_pulsesaved = true;
				Pos_1_pulsesaved = false;
				Pos_3_pulsesaved = false;
				//Pos_4_pulsesaved = false;
				Pos_2_scheduleslot = scheduleslotcounter;
				scheduleslotcounter += 1;
				printf("Pos_2 risetime %d \n", to_ms_since_boot(Pos_2_pulse[0]));
				printf("Pos_2 pulse diff %d scheduled slot %d \n", diff, Pos_2_scheduleslot);
			}
			else
			{
				Pos_2_pulsesaved = false;
				//printf("debounced \n");
			}
			Pos_2_pulse[0] = nil_time;
		}
	}
	else if (SensorINTpin[0] == pin)
	{
		activepos = 3;
		//get pos
		if (gpio_get(pin) && is_nil_time(Pos_3_pulse[0]) && !Pos_3_pulsesaved)
		{ //set time of rise once
			Pos_3_pulse[0] = get_absolute_time();
		}
		else if (gpio_get(pin) == 0 && !is_nil_time(Pos_3_pulse[0]))
		{ //set time of fall if time of rise as already been set
			Pos_3_pulse[1] = get_absolute_time();
			int diff = absolute_time_diff_us(Pos_3_pulse[0], Pos_3_pulse[1]);
			if (diff > debounce)
			{
				//save pulse
				Pos_3_pulsesaved = true;
				Pos_2_pulsesaved = false;
				//Pos_1_pulsesaved = false;
				Pos_4_pulsesaved = false;
				Pos_3_scheduleslot = scheduleslotcounter;
				scheduleslotcounter += 1;
				printf("Pos_3 risetime %d \n", to_ms_since_boot(Pos_3_pulse[0]));
				printf("Pos_3 pulse diff %d scheduled slot %d \n", diff, Pos_3_scheduleslot);
			}
			else
			{
				Pos_3_pulsesaved = false;
				//printf("debounced \n");
			}
			Pos_3_pulse[0] = nil_time;
		}
	}
	else if (SensorINTpin[3] == pin)
	{
		activepos = 4;
		//get pos
		if (gpio_get(pin) && is_nil_time(Pos_4_pulse[0]) && !Pos_4_pulsesaved)
		{ //set time of rise once
			Pos_4_pulse[0] = get_absolute_time();
		}
		else if (gpio_get(pin) == 0 && !is_nil_time(Pos_4_pulse[0]))
		{ //set time of fall if time of rise as already been set
			Pos_4_pulse[1] = get_absolute_time();
			int diff = absolute_time_diff_us(Pos_4_pulse[0], Pos_4_pulse[1]);
			if (diff > debounce)
			{
				//save pulse
				Pos_4_pulsesaved = true;
				//Pos_2_pulsesaved = false;
				Pos_3_pulsesaved = false;
				Pos_1_pulsesaved = false;
				Pos_4_scheduleslot = scheduleslotcounter;
				scheduleslotcounter += 1;
				printf("Pos_4 risetime %d \n", to_ms_since_boot(Pos_4_pulse[0]));
				printf("Pos_4 pulse diff %d scheduled slot %d \n", diff, Pos_4_scheduleslot);
			}
			else
			{
				Pos_4_pulsesaved = false;
				//printf("debounced \n");
			}
			Pos_4_pulse[0] = nil_time;
		}
	}

	//printf("pin state %d nilltime %d pulsesaved %d \n" ,gpio_get(21),is_nil_time(Pos_1_pulse[0]),Pos_1_pulsesaved);

	/*
	int newstartpos = get_encodingState();
	if (newstartpos != startposition)
	{

		//printf("fired pin %d \n",pin);
		//printf(" ---> prevstartpos %d newstartpos %d \n",startposition,newstartpos);
		if (passSynctest(newstartpos))
		{

			printf("using digital ====> prevstartpos--> %d Newstartpos--> %d \n", startposition, newstartpos);
			if (newstartpos == 1)
			{
				if (startposition == 4)
				{
					count += 1; //clockwise
				}
				else if (startposition == 2)
				{
					count -= 1; //counterclockwise
				}
				activesensorINT = 2;
			}
			else if (newstartpos == 2)
			{
				if (startposition == 1)
				{
					count += 1; //clockwise
				}
				else if (startposition == 3)
				{
					count -= 1; //counterclockwise
				}
				activesensorINT = 1;
			}
			else if (newstartpos == 3)
			{
				if (startposition == 2)
				{
					count += 1; //clockwise
				}
				else if (startposition == 4)
				{
					count -= 1; //counterclockwise
				}
				activesensorINT = 2;
			}
			else if (newstartpos == 4)
			{
				if (startposition == 3)
				{
					count += 1; //clockwise
				}
				else if (startposition == 1)
				{
					count -= 1; //counterclockwise
				}
				activesensorINT = 1;
			}
			startposition = newstartpos;
		}
		else
		{
			count = 1000;
			inSync = false;
		}
	}
	else
	{
		INTProcessed = false;
	}
	//startposition = newstartpos;
	*/
	return startposition;
}

int MagRotaryEncoder::sensor1_INT()
{
	//printf("using digital ====> prevstartpos--> %d Newstartpos--> %d \n", prevstartposition, startposition);
	if (!use_extended_resolution)
	{						//extended res is not used
		get_sensorValue(2); //read sensor 2

		//set new startposition
		if (sensor2 != 0)
		{ //value read successfully, process here

			startposition = get_encodingState(1);
			if (startposition == prevstartposition)
			{
				activesensorINT = 2;
				INTProcessed = false;
				return 2;
			}
			prevsensor1 = Mid;
			INTProcessed = true;
			//keep count

			rotationrate = (time_us_64() / 1000) - timetracker; //rotation step rate
			if (startposition == 2)
			{ //new startposition is not == 1 or 4
				if (prevstartposition == 1)
				{ //clockwise
					count++;
				}
				else if (prevstartposition == 3)
				{ //counterclockwise
					count--;
				}
				prevstartposition = startposition;
			}

			else if (startposition == 4)
			{ // new startposition == 4
				if (prevstartposition == 3)
				{ //clockwise
					count++;
				}
				else if (prevstartposition == 1)
				{ //counterclockwise
					count--;
				}
				prevstartposition = startposition;
			}
			prevstartposition = startposition;
			timetracker = (time_us_64() / 1000);

			activesensorINT = 2;
			return 2;
		}
		else
		{ //process in loop
			INTProcessed = false;
			INT1fired = true;
			INT2fired = false;
			rotationrate = (time_us_64() / 1000) - timetracker; //rotation step rate
			timetracker = (time_us_64() / 1000);
			activesensorINT = 2;
			return 2;
		}
	}
	else
	{
		INT1fired = true;
		INT2fired = false;
	}
	activesensorINT = 2;
	return 2;
}

int MagRotaryEncoder::sensor2_INT()
{
	//printf("using digital ====> prevstartpos--> %d Newstartpos--> %d \n", prevstartposition, startposition);
	if (!use_extended_resolution)
	{						//extended res is not used
		get_sensorValue(1); //read sensor 1

		//set new startposition
		if (sensor1 != 0)
		{ //value read successfully, process here

			startposition = get_encodingState(2);
			if (startposition == prevstartposition)
			{
				activesensorINT = 1;
				INTProcessed = false;
				return 1;
			}
			prevsensor2 = Mid;
			INTProcessed = true;

			//keep count

			rotationrate = (time_us_64() / 1000) - timetracker; //rotation step rate
			if (startposition == 3)
			{ //new startposition is not == 1 or 4
				if (prevstartposition == 2)
				{ //clockwise
					count++;
				}
				else if (prevstartposition == 4)
				{ //counterclockwise
					count--;
				}
				prevstartposition = startposition;
			}
			else if (startposition == 1)
			{ // new startposition == 1
				if (prevstartposition == 4)
				{ //clockwise
					count++;
				}
				else if (prevstartposition == 2)
				{ //counterclockwise
					count--;
				}
				prevstartposition = startposition;
			}
			prevstartposition = startposition;
			timetracker = (time_us_64() / 1000);
			activesensorINT = 1;
			return 1;
		}
		else
		{ //process in loop
			INTProcessed = false;
			INT2fired = true;
			INT1fired = false;
			rotationrate = (time_us_64() / 1000) - timetracker; //rotation step rate
			timetracker = (time_us_64() / 1000);
			activesensorINT = 1;
			return 1;
		}
	}
	else
	{
		INT2fired = true;
		INT1fired = false;
	}
	activesensorINT = 1;
	return 1;
}

int MagRotaryEncoder::getActiveSensorInterrupt()
{
	return activesensorINT;
}

MagRotaryEncoder::MagRotaryEncoder(int s1, int ch1, int s2, int ch2)
{ //set sensor pins

	adc_init();
	sensor1_pin = s1;
	sensor1_adc_channel = ch1;
	adc_gpio_init(s1);
	sensor2_pin = s2;
	sensor2_adc_channel = ch2;
	adc_gpio_init(s2);
	useInterrupt = false;

	//printf("s1s %d s1n %d s2s %d s2n %d \n",s1,ch1,s2,ch2);
}

MagRotaryEncoder::MagRotaryEncoder(int s1, int ch1, int s2, int ch2, int s1INTpin, int s2INTpin)
{ //set sensor pins
	adc_init();
	sensor1_pin = s1;
	sensor1_adc_channel = ch1;
	adc_gpio_init(s1);
	sensor2_pin = s2;
	sensor2_adc_channel = ch2;
	adc_gpio_init(s2);
	SensorINTpin[0] = s1INTpin;
	gpio_init(s1INTpin);
	gpio_set_dir(s1INTpin, GPIO_IN);
	gpio_pull_down(s1INTpin);
	SensorINTpin[1] = s2INTpin;
	gpio_init(s2INTpin);
	gpio_set_dir(s2INTpin, GPIO_IN);
	gpio_pull_down(s2INTpin);
	useInterrupt = true;
}

void MagRotaryEncoder::setExclINTmode(int s1, int ch1, int s2, int ch2, bool exclint)
{
	SensorINTpin[0] = s1;
	gpio_init(s1);
	gpio_set_dir(s1, GPIO_IN);
	gpio_pull_up(s1);

	SensorINTpin[2] = ch1;
	gpio_init(ch1);
	gpio_set_dir(ch1, GPIO_IN);
	gpio_pull_up(ch1);

	SensorINTpin[1] = s2;
	gpio_init(s2);
	gpio_set_dir(s2, GPIO_IN);
	gpio_pull_up(s2);

	SensorINTpin[3] = ch2;
	gpio_init(ch2);
	gpio_set_dir(ch2, GPIO_IN);
	gpio_pull_up(ch2);
	useInterrupt = true;
	exclInterrupt = false;
}

bool MagRotaryEncoder::ispinUsed(int pin)
{
	for (size_t i = 0; i < 4; i++)
	{
		if (SensorINTpin[i] == pin)
		{
			return true;
		}
	}
	return false;
}

void MagRotaryEncoder::setResistorDivider(float R1, float R2, float vcc)
{
	float newR2 = R1;
	float newR1 = R1 + R2;

	Neutral[0] = (ADCMaxRes / vcc) * (vcc * newR2 / (newR1 + newR2));

	newR1 = R1;
	newR2 = R1 + R2;

	Neutral[1] = (ADCMaxRes / vcc) * (vcc * newR2 / (newR1 + newR2));
	bound = Neutral[1] - (ADCMaxRes / 2);
}

int MagRotaryEncoder::get_sensorINTpin(int sensornum)
{
	if (sensornum == 1)
	{
		return SensorINTpin[0];
	}
	else if (sensornum == 2)
	{
		return SensorINTpin[1];
	}
	else if (sensornum == 3)
	{
		return SensorINTpin[2];
	}
	else if (sensornum == 4)
	{
		return SensorINTpin[3];
	}
}

void MagRotaryEncoder::set_adcresolution(int res)
{
	if (res == 12)
	{
		ADCMaxRes = 4095;
		absoluteNeutral = 2048;
		bound = 400;
		maxsway = 252;
	}
	else if (res == 10)
	{
		ADCMaxRes = 1023;
		absoluteNeutral = 512;
		bound = 10;
		maxsway = 50;
	}
}

void MagRotaryEncoder::invertCount(bool inv)
{
	invertcount = inv;
}

void MagRotaryEncoder::set_poleStateValues(int sensornum, int np, int nu, int sp)
{ //set ADC values for the poles (northpole, neutral, southpole)
	if (sensornum == 1)
	{
		S1_Neutral[0] = nu - bound;
		S1_Neutral[1] = nu + bound;
		S1_North = S1_Neutral[0];
		S1_South = S1_Neutral[1];
		S1_absoluteneutral = nu;
	}
	if (sensornum == 2)
	{
		S2_Neutral[0] = nu - bound;
		S2_Neutral[1] = nu + bound;
		S2_North = S2_Neutral[0];
		S2_South = S2_Neutral[1];
		S2_absoluteneutral = nu;
	}

	southRegion = Neutral[1] + stablerange;
	northRegion = Neutral[0] - stablerange;
	Neutral[0] = nu - bound;
	Neutral[1] = nu + bound;
	Mid = nu;
}

void MagRotaryEncoder::initialize_encoder()
{																												   //initialize encoder
	set_poleStateValues(1, absoluteNeutral - bound - stepres, absoluteNeutral, absoluteNeutral + bound + stepres); // set the peak ADC values for the (sensor1, northpole, neutralstate, southpole)
	set_poleStateValues(2, absoluteNeutral - bound - stepres, absoluteNeutral, absoluteNeutral + bound + stepres); // set the peak ADC values for the (sensor2, northpole, neutralstate, southpole)
	get_sensorValue(1);
	get_sensorValue(2);
	recaliberate_startPosition();
	prevsensor1 = sensor1;
	prevsensor2 = sensor2;
}

int MagRotaryEncoder::CalibrateSensors(int snum)
{
	int slevel = 0;
	locksensorlevels = true;
	if (snum == 1)
	{
		for (size_t i = 0; i < 10; i++)
		{
			adc_select_input(sensor1_adc_channel);
			slevel += adc_read();
		}
		S1_absoluteneutral = slevel / 10;
		S1_Neutral[0] = S1_absoluteneutral - bound;
		S1_Neutral[1] = S1_absoluteneutral + bound;
		return S1_absoluteneutral;
	}
	else if (snum == 2)
	{
		for (size_t i = 0; i < 10; i++)
		{
			adc_select_input(sensor2_adc_channel);
			slevel += adc_read();
		}
		S2_absoluteneutral = slevel / 10;
		S2_Neutral[0] = S2_absoluteneutral - bound;
		S2_Neutral[1] = S2_absoluteneutral + bound;
		return S2_absoluteneutral;
	}	
}
bool MagRotaryEncoder::LoadCalibrationData(int s1, int s2)
{
	//printf("s1 %d s2 %d \n",s1,s2);
	S1_absoluteneutral = s1;
	S1_Neutral[0] = S1_absoluteneutral - bound;
	S1_Neutral[1] = S1_absoluteneutral + bound;

	S2_absoluteneutral = s2;
	S2_Neutral[0] = S2_absoluteneutral - bound;
	S2_Neutral[1] = S2_absoluteneutral + bound;

	locksensorlevels = true;
	return true;
}

void MagRotaryEncoder::recaliberate_startPosition()
{ //sets the start position based on the ADC values
	haptics(0);
	if (!useInterrupt)
	{ //interrupt detection is not used
		if (startposition == 0)
		{ //STARTING
			if (!exclInterrupt)
			{
				get_sensorValue(1); //read sensor 1
				get_sensorValue(2); //read sensor 2
				int comp1 = sensor1 - absoluteNeutral;
				int comp2 = sensor2 - absoluteNeutral;
				if (comp1 < 0)
				{
					comp1 = comp1 * (-1);
				}
				if (comp2 < 0)
				{
					comp2 = comp2 * (-1);
				}
				if (comp1 < comp2) //sensor1 is in neutral
				{
					//set new startposition
					if (sensor2 > Neutral[1])
					{ //sensor1 = neutral , sensor2 = south
						startposition = 2;
						prevstartposition = 2;
						prevsensor1 = Mid;
					}
					else if (sensor2 < Neutral[0])
					{ //sensor1 = neutral , sensor2 = north
						startposition = 4;
						prevstartposition = 4;
						prevsensor1 = Mid;
					}
				}
				else if (comp2 < comp1) //sensor2 is in neutral
				{
					//set new startposition
					if (sensor1 > Neutral[1])
					{ //sensor2 = neutral , sensor1 = south
						startposition = 3;
						prevstartposition = 3;
						prevsensor2 = Mid;
					}
					else if (sensor1 < Neutral[0])
					{ //sensor2 = neutral , sensor1 = north
						startposition = 1;
						prevstartposition = 1;
						prevsensor2 = Mid;
					}
				}
				//SerialUSB.println(startposition);
			}
			else
			{
				startposition = get_encodingState();
			}
		}
		startposition = get_encodingState();
		if (prevstartposition != startposition)
		{ //if startposition didnt change
			if (startposition == 1 || startposition == 3)
			{
				prevsensor2 = Mid;
			}
			else if (startposition == 2 || startposition == 4)
			{
				prevsensor1 = Mid;
			}
			prevstartposition = startposition;
		}

		count = 0;
	}
	else
	{
		if (use_extended_resolution)
		{ //extended res and interrupt is in use, update sensor values from temp values
			if (INT1fired)
			{
				get_sensorValue(2); //read sensor 2
				//set new startposition
				if (sensor2 > Neutral[1])
				{ //sensor1 = neutral , sensor2 = south
					startposition = 2;
					prevsensor1 = Mid;
				}
				else if (sensor2 < Neutral[0])
				{ //sensor1 = neutral , sensor2 = north
					startposition = 4;
					prevsensor1 = Mid;
				}
				INT1fired = false;
			}
			else if (INT2fired)
			{
				get_sensorValue(1); //read sensor 1
				//set new startposition
				if (sensor1 > Neutral[1])
				{ //sensor2 = neutral , sensor1 = south
					startposition = 3;
					prevsensor2 = Mid;
				}
				else if (sensor1 < Neutral[0])
				{ //sensor2 = neutral , sensor1 = north
					startposition = 1;
					prevsensor2 = Mid;
				}
				INT2fired = false;
			}
		}
		else if (startposition == 0)
		{ //STARTING
			if (!exclInterrupt)
			{
				get_sensorValue(1); //read sensor 1
				get_sensorValue(2); //read sensor 2
				int comp1 = sensor1 - absoluteNeutral;
				int comp2 = sensor2 - absoluteNeutral;
				if (comp1 < 0)
				{
					comp1 = comp1 * (-1);
				}
				if (comp2 < 0)
				{
					comp2 = comp2 * (-1);
				}
				if (comp1 < comp2) //sensor1 is in neutral
				{
					//set new startposition
					if (sensor2 > Neutral[1])
					{ //sensor1 = neutral , sensor2 = south
						startposition = 2;
						prevstartposition = 2;
						prevsensor1 = Mid;
					}
					else if (sensor2 < Neutral[0])
					{ //sensor1 = neutral , sensor2 = north
						startposition = 4;
						prevstartposition = 4;
						prevsensor1 = Mid;
					}
				}
				else if (comp2 < comp1) //sensor2 is in neutral
				{
					//set new startposition
					if (sensor1 > Neutral[1])
					{ //sensor2 = neutral , sensor1 = south
						startposition = 3;
						prevstartposition = 3;
						prevsensor2 = Mid;
					}
					else if (sensor1 < Neutral[0])
					{ //sensor2 = neutral , sensor1 = north
						startposition = 1;
						prevstartposition = 1;
						prevsensor2 = Mid;
					}
				}
				//SerialUSB.println(startposition);
			}
			else
			{
				startposition = get_encodingState();
			}
		}
		else if (exclInterrupt)
		{
			//startposition = get_encodingState();
		}
	}
}
void MagRotaryEncoder::DebugEncoder() {

}

int MagRotaryEncoder::get_sensorValue(int sensornum)
{
	if (sensornum == 1)
	{
		adc_select_input(sensor1_adc_channel);
		sensor1 = adc_read();
		//dynamic sensor value update
		if (!locksensorlevels)
		{
			if (sensor1 > S1_South || sensor1 < S1_North)
			{
				adc_select_input(sensor2_adc_channel);
				sensor2 = adc_read();
				if (sensor2 < absoluteNeutral + maxsway && sensor2 > absoluteNeutral - maxsway)
				{
					if (sensor1 > S1_South)
					{
						S1_South = sensor1;
					}
					else if (sensor1 < S1_North)
					{
						S1_North = sensor1;
					}
					S2_absoluteneutral = sensor2;
					S2_Neutral[0] = S2_absoluteneutral - bound;
					S2_Neutral[1] = S2_absoluteneutral + bound;
				}
			}
		}

		if (use_extended_resolution)
		{
			sensor1 = (sensor1 * alpha) + (prevsmoothsensor1 * (1 - alpha));
			prevsmoothsensor1 = sensor1;
		}
		return sensor1;
	}
	else if (sensornum == 2)
	{
		adc_select_input(sensor2_adc_channel);
		sensor2 = adc_read();
		//dynamic sensor value update
		if (!locksensorlevels)
		{
			if (sensor2 > S2_South || sensor2 < S2_North)
			{
				adc_select_input(sensor1_adc_channel);
				sensor1 = adc_read();
				if (sensor1 < absoluteNeutral + maxsway && sensor1 > absoluteNeutral - maxsway)
				{
					if (sensor2 > S2_South)
					{
						S2_South = sensor2;
					}
					else if (sensor2 < S2_North)
					{
						S2_North = sensor2;
					}
					S1_absoluteneutral = sensor1;
					S1_Neutral[0] = S1_absoluteneutral - bound;
					S1_Neutral[1] = S1_absoluteneutral + bound;
				}
			}
		}

		if (use_extended_resolution)
		{
			sensor2 = (sensor2 * alpha) + (prevsmoothsensor2 * (1 - alpha));
			prevsmoothsensor2 = sensor2;
		}
		return sensor2;
	}
}

int MagRotaryEncoder::get_sensorValue(int sensornum, bool ret)
{
	if (sensornum == 1)
	{
		adc_select_input(sensor1_adc_channel);
		return adc_read();
	}
	else if (sensornum == 2)
	{
		adc_select_input(sensor2_adc_channel);
		return adc_read();
	}
}

int MagRotaryEncoder::get_encodingState()
{

	if (!exclInterrupt)
	{
		if (sensor1 < S1_Neutral[0] && sensor2 >= (S2_Neutral[0]) && sensor2 <= (S2_Neutral[1]))
		{ //sensor1 = north , sensor2 = neutral
			return 1;
		}
		else if (sensor1 >= (S1_Neutral[0]) && sensor1 <= (S1_Neutral[1]) && sensor2 > S2_Neutral[1])
		{ //sensor1 = neutral , sensor2 = south
			return 2;
		}
		else if (sensor1 > S1_Neutral[1] && sensor2 >= (S2_Neutral[0]) && sensor2 <= (S2_Neutral[1]))
		{ //sensor1 = south , sensor2 = neutral
			return 3;
		}
		else if (sensor1 >= (S1_Neutral[0]) && sensor1 <= (S1_Neutral[1]) && sensor2 < S2_Neutral[0])
		{ //sensor1 = neutral , sensor2 = north
			return 4;
		}
	}
	else
	{
		//printf("here %d \n",gpio_get(SensorINTpin[2]));
		//digital only detection
		if (gpio_get(SensorINTpin[2]) == 1)
		{

			if (debouncePin(SensorINTpin[2]))
			{
				if (gpio_get(SensorINTpin[1]) == gpio_get(SensorINTpin[3]))
				{
					return 1;
				}
			}
		}
		else if (gpio_get(SensorINTpin[1]) == 1)
		{

			if (debouncePin(SensorINTpin[1]))
			{
				if (gpio_get(SensorINTpin[0]) == gpio_get(SensorINTpin[2]))
				{
					return 2;
				}
			}
		}
		else if (gpio_get(SensorINTpin[0]) == 1)
		{
			if (debouncePin(SensorINTpin[0]))
			{
				if (gpio_get(SensorINTpin[1]) == gpio_get(SensorINTpin[3]))
				{
					return 3;
				}
			}
		}
		else if (gpio_get(SensorINTpin[3]) == 1)
		{
			if (debouncePin(SensorINTpin[3]))
			{
				if (gpio_get(SensorINTpin[0]) == gpio_get(SensorINTpin[2]))
				{
					return 4;
				}
			}
		}
		return startposition;
	}

	return startposition;
}

int MagRotaryEncoder::get_encodingState(int incenter)
{

	if (gpio_get(SensorINTpin[0]) != gpio_get(SensorINTpin[1]) && XOR_INTPins())
	{
		if (incenter == 1)
		{
			if (sensor2 > Neutral[1])
			{ //sensor1 = neutral , sensor2 = south
				return 2;
			}

			else if (sensor2 < Neutral[0])
			{ //sensor1 = neutral , sensor2 = north
				return 4;
			}
		}
		else if (incenter == 2)
		{
			if (sensor1 > Neutral[1])
			{ //sensor2 = neutral , sensor1 = south
				return 3;
			}

			else if (sensor1 < Neutral[0])
			{ //sensor2 = neutral , sensor1 = north
				return 1;
			}
		}
	}

	return startposition;
}

int MagRotaryEncoder::get_currentSensorValue(int sensornum)
{
	if (sensornum == 1)
	{
		return sensor1;
	}
	else if (sensornum == 2)
	{
		return sensor2;
	}
}

int MagRotaryEncoder::get_encResCount(int retstep)
{
	//keep counter value in the encoder's resolution range
	if (retstep < 0)
	{
		for (int i = 0; i > retstep; i--)
		{
			if ((encoderPosition - 1) >= 1)
			{
				encoderPosition = encoderPosition - 1;
			}
			else if ((encoderPosition - 1) < 1)
			{
				encoderPosition = encoderResolution;
			}
		}
	}
	else if (retstep > 0)
	{
		for (int i = 0; i < retstep; i++)
		{
			if ((encoderPosition + 1) <= encoderResolution)
			{
				encoderPosition = encoderPosition + 1;
			}
			else if ((encoderPosition + 1) > encoderResolution)
			{
				encoderPosition = 1;
			}
		}
	}
	//SerialUSB.println(retstep);
	//validate stored start point data
	//SerialUSB.print("\t");
	//SerialUSB.println(encoderPosition);
	if (encoderPosition == 1)
	{

		//get_sensorValue(1);
		//get_sensorValue(2);
		/*
		SerialUSB.print(storedstartposition);
		SerialUSB.print("\t");
		SerialUSB.print(startposition);
		SerialUSB.print("\t");
		SerialUSB.print(storedsensor1state);
		SerialUSB.print("\t");
		SerialUSB.print(sensor1);
		SerialUSB.print("\t");
		SerialUSB.print(storedsensor2state);
		SerialUSB.print("\t");
		SerialUSB.println(sensor2);
		*/
		int passmark = 0;
		inSync = false;
		if (storedstartposition == startposition)
		{

			passmark += 1;
			/*
			if (storedsensor1state > Neutral[1] && sensor1 > Neutral[1] || storedsensor1state < Neutral[0] && sensor1 < Neutral[0]
				|| storedsensor1state > Neutral[1] && sensor1 > Neutral[1] || storedsensor1state < Neutral[0] && sensor1 < Neutral[0]
				)
			{
				passmark += 1;
			}

			if (storedsensor2state > Neutral[1] && sensor2 > Neutral[1] || storedsensor2state < Neutral[0] && sensor2 < Neutral[0]
				|| storedsensor2state > Neutral[1] && sensor2 > Neutral[1] || storedsensor2state < Neutral[0] && sensor2 < Neutral[0]
				)
			{
				passmark += 1;
			}
			*/
		}
		if (passmark == 1)
		{
			inSync = true;
		}
	}

	if (inSync)
	{
		return encoderPosition;
	}
	else
	{
		encoderPosition = -1;
		return encoderPosition;
	}
}

void MagRotaryEncoder::set_encoderResolution(int res)
{
	encoderResolution = res;
	encoderPosition = 0;
	storedstartposition = 0;
	storedsensor1state = 0;
	storedsensor2state = 0;
	inSync = false;
}

int MagRotaryEncoder::setToStart()
{
	//printf("Neutral 1 %d Neutral 0 %d \n", Neutral[1], Neutral[0]);
	encoderPosition = 1;

	startposition = 0;
	get_sensorValue(1);
	get_sensorValue(2);
	recaliberate_startPosition();
	count = 0;
	//printf("newsetstart %d bound %d \n",startposition,bound);
	if (startposition != 0)
	{
		storedstartposition = startposition;
		storedsensor1state = sensor1;
		storedsensor2state = sensor2;
		inSync = true;
		return encoderPosition;
	}
	else
	{
		return -1;
	}
}

int MagRotaryEncoder::detect_rotation()
{ // openloop rotation encoding function
	//printf("s1s %d s1n %d s2s %d s2n %d \n",SensorINTpin[0],SensorINTpin[2],SensorINTpin[1],SensorINTpin[3]);
	if (!useInterrupt)
	{ //interrupt detection is not used
		//printf("s1absneutral %d, s2absneutral %d, bound %d \n", S1_absoluteneutral, S2_absoluteneutral, bound);
		get_sensorValue(1);
		get_sensorValue(2);
		int newstate = get_encodingState();
		if (newstate != startposition)
		{
			if (!passSynctest(newstate))
			{
				count = 1000;
				inSync = false;
			}
		}

		//printf("prev %d newstartpos %d \n",startposition,newstate);
		if (startposition == 1)
		{
			if (newstate == 2)
			{
				rotation_action(1);
				haptics(1);
			}
			else if (newstate == 4)
			{
				rotation_action(0);
				haptics(1);
			}
		}

		else if (startposition == 2)
		{
			if (newstate == 3)
			{
				rotation_action(1);
				haptics(1);
			}
			else if (newstate == 1)
			{
				rotation_action(0);
				haptics(1);
			}
		}

		else if (startposition == 3)
		{
			if (newstate == 4)
			{
				rotation_action(1);
				haptics(1);
			}
			else if (newstate == 2)
			{
				rotation_action(0);
				haptics(1);
			}
		}

		else if (startposition == 4)
		{
			if (newstate == 1)
			{
				rotation_action(1);
				haptics(1);
			}
			else if (newstate == 3)
			{
				rotation_action(0);
				haptics(1);
			}
		}
		//printf("startpos %d, s1 %d,s2 %d \n",startposition,sensor1,sensor2);

		if (count != 0)
		{
			if (invertcount)
			{
				count *= -1;
			}
			haptics(1);

			if (encoderResolution > 0)
			{
				if (inSync)
				{
					tempcount = count;
					recaliberate_startPosition();
					tempcount = get_encResCount(tempcount);
					//SerialUSB.print(tempcount);
				}
				else
				{
					recaliberate_startPosition();
					tempcount = -1;
				}
			}
			else
			{
				tempcount = count;
				recaliberate_startPosition();
			}
			count = 0;
			return tempcount;
		}
		else
		{
			tempcount = count;
			recaliberate_startPosition();
			return 0;
		}
	}
	else
	{
		if (!exclInterrupt)
		{
			if (INTProcessed)
			{ //processed in interrupt

				if (count != 0)
				{
					if (invertcount)
					{
						count *= -1;
					}
					haptics(1);

					if (encoderResolution > 0)
					{
						if (inSync)
						{
							tempcount = count;
							recaliberate_startPosition();
							tempcount = get_encResCount(tempcount);
							//SerialUSB.print(tempcount);
						}
						else
						{
							tempcount = -1;
						}
					}
					else
					{
						tempcount = count;
						recaliberate_startPosition();
					}
					count = 0;
					return tempcount;
				}
				else
				{
					tempcount = count;
					recaliberate_startPosition();
					return 0;
				}
			}
			else
			{
				if (!gpio_get(SensorINTpin[1])) //int1 active
				{
					get_sensorValue(2);
					startposition = get_encodingState(1);
					if (startposition != prevstartposition)
					{
						rotationrate = (time_us_64() / 1000) - timetracker; //rotation step rate
						if (startposition == 2)
						{ //new startposition is not == 1 or 4
							if (prevstartposition == 1)
							{ //clockwise
								count++;
							}
							else if (prevstartposition == 3)
							{ //counterclockwise
								count--;
							}
							prevstartposition = startposition;
						}

						else if (startposition == 4)
						{ // new startposition == 4
							if (prevstartposition == 3)
							{ //clockwise
								count++;
							}
							else if (prevstartposition == 1)
							{ //counterclockwise
								count--;
							}
							prevstartposition = startposition;
						}
						prevstartposition = startposition;
						timetracker = (time_us_64() / 1000);
						INTProcessed = true;
					}
				}
				else if (!gpio_get(SensorINTpin[0])) //int2 active
				{
					get_sensorValue(1);
					startposition = get_encodingState(2);
					if (startposition != prevstartposition)
					{
						rotationrate = (time_us_64() / 1000) - timetracker; //rotation step rate
						if (startposition == 3)
						{ //new startposition is not == 1 or 4
							if (prevstartposition == 2)
							{ //clockwise
								count++;
							}
							else if (prevstartposition == 4)
							{ //counterclockwise
								count--;
							}
							prevstartposition = startposition;
						}
						else if (startposition == 1)
						{ // new startposition == 1
							if (prevstartposition == 4)
							{ //clockwise
								count++;
							}
							else if (prevstartposition == 2)
							{ //counterclockwise
								count--;
							}
							prevstartposition = startposition;
						}
						prevstartposition = startposition;
						timetracker = (time_us_64() / 1000);
						INTProcessed = true;
					}
				}
				if (count != 0)
				{
					if (invertcount)
					{
						count *= -1;
					}
					haptics(1);

					if (encoderResolution > 0)
					{
						if (inSync)
						{
							tempcount = count;
							tempcount = get_encResCount(tempcount);
							//SerialUSB.print(tempcount);
						}
						else
						{
							tempcount = -1;
						}
					}
					else
					{
						tempcount = count;
						//recaliberate_startPosition();
					}
					count = 0;
					return tempcount;
				}
				else
				{
					tempcount = count;
					recaliberate_startPosition();
					return 0;
				}
			}
			tempcount = count;
			//recaliberate_startPosition();
			return 0;
		}
		else
		{

			if (count != 0)
			{
				if (invertcount)
				{
					count *= -1;
				}
				haptics(1);

				if (encoderResolution > 0)
				{
					if (inSync)
					{
						tempcount = count;
						recaliberate_startPosition();
						tempcount = get_encResCount(tempcount);
						//SerialUSB.print(tempcount);
					}
					else
					{
						tempcount = -1;
					}
				}
				else
				{
					tempcount = count;
					recaliberate_startPosition();
				}
				count = 0;
				return tempcount;
			}
			else
			{
				tempcount = count;
				recaliberate_startPosition();
				return 0;
			}
		}
	}
}

int MagRotaryEncoder::detect_rotationWithRate()
{ // openloop rotation encoding function

	if (!useInterrupt)
	{ //interrupt detection is not used
		get_sensorValue(1);
		get_sensorValue(2);
		int newstate = get_encodingState();
		if (startposition == 1)
		{
			if (newstate == 2)
			{
				rotationrate = (time_us_64() / 1000) - timetracker;
				timetracker = (time_us_64() / 1000);
				rotation_action(1);
				haptics(1);
			}
			else if (newstate == 4)
			{
				rotationrate = (time_us_64() / 1000) - timetracker;
				timetracker = (time_us_64() / 1000);
				rotation_action(0);
				haptics(1);
			}
		}

		else if (startposition == 2)
		{
			if (newstate == 3)
			{
				rotationrate = (time_us_64() / 1000) - timetracker;
				timetracker = (time_us_64() / 1000);
				rotation_action(1);
				haptics(1);
			}
			else if (newstate == 1)
			{
				rotationrate = (time_us_64() / 1000) - timetracker;
				timetracker = (time_us_64() / 1000);
				rotation_action(0);
				haptics(1);
			}
		}

		else if (startposition == 3)
		{
			if (newstate == 4)
			{
				rotationrate = (time_us_64() / 1000) - timetracker;
				timetracker = (time_us_64() / 1000);
				rotation_action(1);
				haptics(1);
			}
			else if (newstate == 2)
			{
				rotationrate = (time_us_64() / 1000) - timetracker;
				timetracker = (time_us_64() / 1000);
				rotation_action(0);
				haptics(1);
			}
		}

		else if (startposition == 4)
		{
			if (newstate == 1)
			{
				rotationrate = (time_us_64() / 1000) - timetracker;
				timetracker = (time_us_64() / 1000);
				rotation_action(1);
				haptics(1);
			}
			else if (newstate == 3)
			{
				rotationrate = (time_us_64() / 1000) - timetracker;
				timetracker = (time_us_64() / 1000);
				rotation_action(0);
				haptics(1);
			}
		}

		if (count != 0)
		{

			if (invertcount)
			{
				count *= -1;
			}
			haptics(1);
			if (rotationrate > 0)
			{ //avoid negative values
				if (rotationrate < timetomultiply)
				{ //not fast anough for multiplier
					float calcmul = 1 - ((float)rotationrate / (float)timetomultiply);
					count = count * multiplier * calcmul;
					//timetracker = (time_us_64()/1000);
				}
			}
			tempcount = count;
			recaliberate_startPosition();

			count = 0;
			return tempcount;
		}
		else
		{
			tempcount = count;
			recaliberate_startPosition();
			return 0;
		}
	}
	else
	{
		if (INTProcessed)
		{ //processed in interrupt

			if (count != 0)
			{

				if (invertcount)
				{
					count *= -1;
				}
				haptics(1);
				if (rotationrate > 0)
				{ //avoid negative values
					if (rotationrate < timetomultiply)
					{ //not fast anough for multiplier
						float calcmul = 1 - ((float)rotationrate / (float)timetomultiply);
						count = count * multiplier * calcmul;
						//timetracker = (time_us_64()/1000);
					}
				}
				tempcount = count;
				recaliberate_startPosition();

				count = 0;
				return tempcount;
			}
			else
			{
				tempcount = count;
				recaliberate_startPosition();
				return 0;
			}
		}
		else
		{
			if (!gpio_get(SensorINTpin[1])) //int1 active
			{
				get_sensorValue(2);
				startposition = get_encodingState(1);
				if (startposition != prevstartposition)
				{
					rotationrate = (time_us_64() / 1000) - timetracker; //rotation step rate
					if (startposition == 2)
					{ //new startposition is not == 1 or 4
						if (prevstartposition == 1)
						{ //clockwise
							count++;
						}
						else if (prevstartposition == 3)
						{ //counterclockwise
							count--;
						}
						prevstartposition = startposition;
					}

					else if (startposition == 4)
					{ // new startposition == 4
						if (prevstartposition == 3)
						{ //clockwise
							count++;
						}
						else if (prevstartposition == 1)
						{ //counterclockwise
							count--;
						}
						prevstartposition = startposition;
					}
					prevstartposition = startposition;
					timetracker = (time_us_64() / 1000);
					INTProcessed = true;
				}
			}
			else if (!gpio_get(SensorINTpin[0])) //int2 active
			{
				get_sensorValue(1);
				startposition = get_encodingState(2);
				if (startposition != prevstartposition)
				{
					rotationrate = (time_us_64() / 1000) - timetracker; //rotation step rate
					if (startposition == 3)
					{ //new startposition is not == 1 or 4
						if (prevstartposition == 2)
						{ //clockwise
							count++;
						}
						else if (prevstartposition == 4)
						{ //counterclockwise
							count--;
						}
						prevstartposition = startposition;
					}
					else if (startposition == 1)
					{ // new startposition == 1
						if (prevstartposition == 4)
						{ //clockwise
							count++;
						}
						else if (prevstartposition == 2)
						{ //counterclockwise
							count--;
						}
						prevstartposition = startposition;
					}
					prevstartposition = startposition;
					timetracker = (time_us_64() / 1000);
					INTProcessed = true;
				}
			}
			if (count != 0)
			{

				if (invertcount)
				{
					count *= -1;
				}
				haptics(1);
				if (rotationrate > 0)
				{ //avoid negative values
					if (rotationrate < timetomultiply)
					{ //not fast anough for multiplier
						float calcmul = 1 - ((float)rotationrate / (float)timetomultiply);
						count = count * multiplier * calcmul;
						//timetracker = (time_us_64()/1000);
					}
				}
				tempcount = count;
				recaliberate_startPosition();

				count = 0;
				return tempcount;
			}
			else
			{
				tempcount = count;
				recaliberate_startPosition();
				return 0;
			}
		}
		tempcount = count;
		recaliberate_startPosition();
		return 0;
	}
}

int MagRotaryEncoder::detect_rotationHR()
{ // openloop rotation encoding function

	int sensvalrange = 0;

	if (!useInterrupt)
	{ //interrupt detection is not used
		if (startposition == 1)
		{ //sensor2 is in neutral
			get_sensorValue(1);
			get_sensorValue(2);
			if (!(sensor2 < Neutral[1] && sensor2 > Neutral[0]))
			{ //analog value is not in the neutral range
				// check for actual rotation
				if (prevsensor2 != Mid)
				{
					if (sensor2 > (prevsensor2 + setresolution) || sensor2 < (prevsensor2 - setresolution))
					{
						//get distance from north and south pole magnets
						distance = prevsensor2 - sensor2;
						//check rotation direction with distance values
						if (distance > 0)
						{ //moved towards magnet northpole
							prevsensor2 = sensor2 + setresolution - (setresolution - 1);
							rotation_action(0);
							haptics(1);
						}
						else if (distance < 0)
						{ //moved towards magnet southpole
							prevsensor2 = sensor2 - setresolution + (setresolution - 1);
							rotation_action(1);
							haptics(1);
						}
					}
				}
				else
				{
					prevsensor2 = sensor2;
				}
			}
		}

		else if (startposition == 2)
		{ //sensor1 is in neutral
			get_sensorValue(1);
			get_sensorValue(2);
			if (!(sensor1 < Neutral[1] && sensor1 > Neutral[0]))
			{ //analog value is not in the neutral range
				// check for actual rotation
				if (prevsensor1 != Mid)
				{
					// check for actual rotation
					if (sensor1 > (prevsensor1 + setresolution) || sensor1 < (prevsensor1 - setresolution))
					{
						//get distance from north and south pole magnets
						distance = prevsensor1 - sensor1;
						//check rotation direction with distance values
						if (distance > 0)
						{ //moved towards magnet northpole
							prevsensor1 = sensor1 + setresolution - (setresolution - 1);
							rotation_action(0);
							haptics(1);
						}
						else if (distance < 0)
						{ //moved towards magnet southpole
							prevsensor1 = sensor1 - setresolution + (setresolution - 1);
							rotation_action(1);
							haptics(1);
						}
					}
				}
				else
				{
					prevsensor1 = sensor1;
				}
			}
		}

		else if (startposition == 3)
		{ //sensor2 is in neutral
			get_sensorValue(1);
			get_sensorValue(2);
			if (!(sensor2 < Neutral[1] && sensor2 > Neutral[0]))
			{ //analog value is not in the neutral range
				// check for actual rotation
				if (prevsensor2 != Mid)
				{
					// check for actual rotation
					if (sensor2 > (prevsensor2 + setresolution) || sensor2 < (prevsensor2 - setresolution))
					{
						distance = prevsensor2 - sensor2;
						//check rotation direction with distance values
						if (distance > 0)
						{ //moved towards magnet northpole
							prevsensor2 = sensor2 + setresolution - (setresolution - 1);
							rotation_action(1);
							haptics(1);
						}
						else if (distance < 0)
						{ //moved towards magnet southpole
							prevsensor2 = sensor2 - setresolution + (setresolution - 1);
							rotation_action(0);
							haptics(1);
						}
					}
				}
				else
				{
					prevsensor2 = sensor2;
				}
			}
		}

		else if (startposition == 4)
		{ //sensor1 is in neutral
			get_sensorValue(1);
			get_sensorValue(2);
			if (!(sensor1 < Neutral[1] && sensor1 > Neutral[0]))
			{ //analog value is not in the neutral range
				// check for actual rotation
				if (prevsensor1 != Mid)
				{
					// check for actual rotation
					if (sensor1 > (prevsensor1 + setresolution) || sensor1 < (prevsensor1 - setresolution))
					{
						//get distance from north and south pole magnets
						distance = prevsensor1 - sensor1;
						//check rotation direction with distance values
						if (distance > 0)
						{ //moved towards magnet northpole
							prevsensor1 = sensor1 + setresolution - (setresolution - 1);
							;
							rotation_action(1);
							haptics(1);
						}
						else if (distance < 0)
						{ //moved towards magnet southpole
							prevsensor1 = sensor1 - setresolution + (setresolution - 1);
							;
							rotation_action(0);
							haptics(1);
						}
					}
				}
				else
				{
					prevsensor1 = sensor1;
				}
			}
		}

		else
		{
			get_sensorValue(1);
			get_sensorValue(2);
		}
		tempcount = count;
		/*
		countt += tempcount;
		if (tempcount != 0) {
			SerialUSB.print(setresolution);
			SerialUSB.print("\t");
			SerialUSB.print(sensor1);
			SerialUSB.print("\t");
			SerialUSB.print(prevsensor1);
			SerialUSB.print("\t");
			SerialUSB.print(sensor2);
			SerialUSB.print("\t");
			SerialUSB.print(prevsensor2);
			SerialUSB.print("\t");
			SerialUSB.print(startposition);
			SerialUSB.print("\t");
			SerialUSB.print(tempcount);
			SerialUSB.print("\t");
			SerialUSB.println(countt);

		}
		*/

		recaliberate_startPosition();
		return tempcount;
	}
	else
	{ //interrupt assisted
		if (INT1fired)
		{
			get_sensorValue(2);
			startposition = get_encodingState(1);
		}
		else if (INT2fired)
		{
			get_sensorValue(1);
			startposition = get_encodingState(2);
		}

		if (startposition == 1)
		{ //sensor2 is in neutral
			//get_sensorValue(1);
			get_sensorValue(2);

			if (!(sensor2 < Neutral[1] && sensor2 > Neutral[0]))
			{ //analog value is not in the neutral range
				// check for actual rotation
				if (prevsensor2 != Mid)
				{
					if (sensor2 > (prevsensor2 + setresolution) || sensor2 < (prevsensor2 - setresolution))
					{
						//get distance from north and south pole magnets
						distance = prevsensor2 - sensor2;
						//check rotation direction with distance values
						if (distance > 0)
						{ //moved towards magnet northpole
							prevsensor2 = sensor2 + setresolution - (setresolution - 1);
							rotation_action(0);
							haptics(1);
						}
						else if (distance < 0)
						{ //moved towards magnet southpole
							prevsensor2 = sensor2 - setresolution + (setresolution - 1);
							rotation_action(1);
							haptics(1);
						}
					}
				}
				else
				{
					prevsensor2 = sensor2;
				}
			}
		}

		else if (startposition == 2)
		{ //sensor1 is in neutral

			get_sensorValue(1);
			//get_sensorValue(2);

			if (!(sensor1 < Neutral[1] && sensor1 > Neutral[0]))
			{ //analog value is not in the neutral range
				// check for actual rotation
				if (prevsensor1 != Mid)
				{
					// check for actual rotation
					if (sensor1 > (prevsensor1 + setresolution) || sensor1 < (prevsensor1 - setresolution))
					{
						//get distance from north and south pole magnets
						distance = prevsensor1 - sensor1;
						//check rotation direction with distance values
						if (distance > 0)
						{ //moved towards magnet northpole
							prevsensor1 = sensor1 + setresolution - (setresolution - 1);
							rotation_action(0);
							haptics(1);
						}
						else if (distance < 0)
						{ //moved towards magnet southpole
							prevsensor1 = sensor1 - setresolution + (setresolution - 1);
							rotation_action(1);
							haptics(1);
						}
					}
				}
				else
				{
					prevsensor1 = sensor1;
				}
			}
		}

		else if (startposition == 3)
		{ //sensor2 is in neutral

			//get_sensorValue(1);
			get_sensorValue(2);

			if (!(sensor2 < Neutral[1] && sensor2 > Neutral[0]))
			{ //analog value is not in the neutral range
				// check for actual rotation
				if (prevsensor2 != Mid)
				{
					// check for actual rotation
					if (sensor2 > (prevsensor2 + setresolution) || sensor2 < (prevsensor2 - setresolution))
					{
						distance = prevsensor2 - sensor2;
						//check rotation direction with distance values
						if (distance > 0)
						{ //moved towards magnet northpole
							prevsensor2 = sensor2 + setresolution - (setresolution - 1);
							rotation_action(1);
							haptics(1);
						}
						else if (distance < 0)
						{ //moved towards magnet southpole
							prevsensor2 = sensor2 - setresolution + (setresolution - 1);
							rotation_action(0);
							haptics(1);
						}
					}
				}
				else
				{
					prevsensor2 = sensor2;
				}
			}
		}

		else if (startposition == 4)
		{ //sensor1 is in neutral

			get_sensorValue(1);
			//get_sensorValue(2);

			if (!(sensor1 < Neutral[1] && sensor1 > Neutral[0]))
			{ //analog value is not in the neutral range
				// check for actual rotation
				if (prevsensor1 != Mid)
				{
					// check for actual rotation
					if (sensor1 > (prevsensor1 + setresolution) || sensor1 < (prevsensor1 - setresolution))
					{
						//get distance from north and south pole magnets
						distance = prevsensor1 - sensor1;
						//check rotation direction with distance values
						if (distance > 0)
						{ //moved towards magnet northpole
							prevsensor1 = sensor1 + setresolution - (setresolution - 1);
							;
							rotation_action(1);
							haptics(1);
						}
						else if (distance < 0)
						{ //moved towards magnet southpole
							prevsensor1 = sensor1 - setresolution + (setresolution - 1);
							;
							rotation_action(0);
							haptics(1);
						}
					}
				}
				else
				{
					prevsensor1 = sensor1;
				}
			}
		}

		if (invertcount)
		{
			count *= -1;
		}

		tempcount = count;
		recaliberate_startPosition();
		return tempcount;
	}
}

void MagRotaryEncoder::set_resolution(int percent)
{
	if (percent == 100)
	{
		setresolution = 1;
		use_extended_resolution = true;
	}
	else if (percent == 0)
	{
		use_extended_resolution = false;
	}
	else
	{
		setresolution = stepres - ((percent * 0.01) * stepres);
		use_extended_resolution = true;
	}
}

void MagRotaryEncoder::rotation_action(int act)
{ //sets action for clockwise and anticlockwise rotations
	if (act == 1)
	{
		count++;
	}
	else if (act == 0)
	{
		count--;
	}
}

void MagRotaryEncoder::set_bound(int b)
{ //this value determines the upper and lower limit of the ADC values
	bound = b;
	Neutral[0] = absoluteNeutral - bound;
	Neutral[1] = absoluteNeutral + bound;
}
void MagRotaryEncoder::useinterruptdetection(bool act)
{
	useInterrupt = act;
}

void MagRotaryEncoder::set_haptics(int pin, int duration, int strength)
{ //use to set haptics variables (arduino pwm pin, duration of haptics(ms), strength from 0-255)
	haptics_pin = pin;
	haptics_duration = duration;
	haptics_strength = strength;

	// Tell GPIO 0 and 1 they are allocated to the PWM
	gpio_set_function(pin, GPIO_FUNC_PWM);

	// Find out which PWM slice is connected to GPIO 0 (it's slice 0)
	uint slice_num = pwm_gpio_to_slice_num(pin);

	// Set period of 4 cycles (0 to 3 inclusive)
	pwm_set_wrap(slice_num, 255);
	// Set channel A output high for one cycle before dropping
	pwm_set_chan_level(slice_num, PWM_CHAN_A, 0);
	// Set the PWM running
	pwm_set_enabled(slice_num, true);
}

void MagRotaryEncoder::haptics(int state)
{ //viberation feedback function
	if (state == 1)
	{
		pwm_set_gpio_level(haptics_pin, haptics_strength);
		haptics_ontime = (time_us_64() / 1000);
		haptics_state = 1;
	}
	else
	{
		haptics_offtime = (time_us_64() / 1000);
		if (((haptics_offtime - haptics_ontime) >= haptics_duration) && haptics_state == 1)
		{
			pwm_set_gpio_level(haptics_pin, 0);
			haptics_state = 0;
		}
	}
	/*
	analogWrite(haptics_pin, haptics_strength);
	delay(haptics_duration);
	analogWrite(haptics_pin, 0);
	*/
}

void MagRotaryEncoder::setsleep(bool slpact)
{
	sleepmode = slpact;
}

bool MagRotaryEncoder::readsleep()
{
	return sleepmode;
}
