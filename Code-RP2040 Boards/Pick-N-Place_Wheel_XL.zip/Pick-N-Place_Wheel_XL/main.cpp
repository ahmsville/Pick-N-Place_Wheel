#include <stdio.h>
#include "pico/stdlib.h"
#include "MagRotaryEncoding.h"
#include <string>
#include <string.h>
#include <iostream>
#include "hardware/adc.h"
#include "hardware/pwm.h"
#include "ws2812.pio.h"

#define INTpin1 20
#define INTpin2 21
#define RISING 0x08
#define FALLING 0x04

#define red 1
#define green 2
#define blue 3

#define NUM_LEDS 2

using namespace std;

MagRotaryEncoder wheel1 = MagRotaryEncoder(26, 0, 27, 1);
MagRotaryEncoder wheel2 = MagRotaryEncoder(28, 2, 29, 3);

char inbuff[100];
int buffcounter = 0;
bool dataavailable = false;
string inString = "";
string outstr = "";

int Wheel1_Slot = 1;
int Wheel1_SlotCount = 72;
int retstep1;
bool Wheel1reset = false;
string wheel1outstring = "w1x";

int Wheel2_Slot = 1;
int Wheel2_SlotCount = 36;
int retstep2;
bool Wheel2reset = false;
string wheel2outstring = "w2x";

int activeledcolor[2] = {0, 0};

const int PIN_TX = 8;
volatile int activesensor1Interrupt = 1; //used for switching active ISR
volatile int activesensor2Interrupt = 1; //used for switching active ISR

static inline void put_pixel(uint32_t pixel_grb)
{
  pio_sm_put_blocking(pio0, 0, pixel_grb << 8u);
}

static inline uint32_t urgb_u32(uint8_t r, uint8_t g, uint8_t b)
{
  return ((uint32_t)(r) << 8) |
         ((uint32_t)(g) << 16) |
         (uint32_t)(b);
}

void ISR1()
{
  if (activesensor1Interrupt == 1)
  { //sensor 1 interrupt is active.
    activesensor1Interrupt = wheel1.sensor1_INT();
  }
}
void ISR2()
{
  if (activesensor1Interrupt == 2)
  { //sensor 1 interrupt is active.
    activesensor1Interrupt = wheel1.sensor2_INT();
  }
}

void ISR3()
{
  if (activesensor2Interrupt == 1)
  { //sensor 1 interrupt is active.
    activesensor2Interrupt = wheel2.sensor1_INT();
  }
}
void ISR4()
{
  if (activesensor2Interrupt == 2)
  { //sensor 1 interrupt is active.
    activesensor2Interrupt = wheel2.sensor2_INT();
  }
}

void isr1(uint gpiopin, uint32_t events)
{

  //printf("fired on pin %d event %d \n", gpiopin, events);
  if (wheel1.ispinUsed(gpiopin))
  {
    for (size_t i = 0; i < 4; i++)
    {
      gpio_acknowledge_irq(wheel1.get_sensorINTpin(i), RISING & FALLING);
      //gpio_set_irq_enabled(wheel1.get_sensorINTpin(i), RISING | FALLING, false);
    }
    wheel1.singleISR(gpiopin);
  }
  else if (wheel2.ispinUsed(gpiopin))
  {
    for (size_t i = 0; i < 4; i++)
    {
      gpio_acknowledge_irq(wheel2.get_sensorINTpin(i), RISING | FALLING);
    }
    wheel2.singleISR(gpiopin);
  }

  /*
  if (gpiopin == 2 || gpiopin == 3) //enc1 s1
  {
    ISR1();
  }
  else if (gpiopin == 4 || gpiopin == 5)//enc1 s2
  {
    ISR2();
  }
  
  if (gpiopin == 10 || gpiopin == 11) //enc2 s1
  {
    ISR3();
  }
  else if (gpiopin == 12 || gpiopin == 13)//enc2 s2
  {
    ISR4();
  }
  */

  //printf("state %d \n",gpio_get(INTpin1));
}
void setinterrupt()
{
  wheel1.setExclINTmode(2, 3, 4, 5, true);

  int pinNum = wheel1.get_sensorINTpin(1);
  gpio_set_irq_enabled_with_callback(pinNum, RISING | FALLING, true, isr1);
  pinNum = wheel1.get_sensorINTpin(2);
  gpio_set_irq_enabled_with_callback(pinNum, RISING | FALLING, true, isr1);
  pinNum = wheel1.get_sensorINTpin(3);
  gpio_set_irq_enabled_with_callback(pinNum, RISING | FALLING, true, isr1);
  pinNum = wheel1.get_sensorINTpin(4);
  gpio_set_irq_enabled_with_callback(pinNum, RISING | FALLING, true, isr1);

  wheel2.setExclINTmode(10, 11, 12, 13, true);
  pinNum = wheel2.get_sensorINTpin(1);
  gpio_set_irq_enabled_with_callback(pinNum, RISING | FALLING, true, isr1);
  pinNum = wheel2.get_sensorINTpin(2);
  gpio_set_irq_enabled_with_callback(pinNum, RISING | FALLING, true, isr1);
  pinNum = wheel2.get_sensorINTpin(3);
  gpio_set_irq_enabled_with_callback(pinNum, RISING | FALLING, true, isr1);
  pinNum = wheel2.get_sensorINTpin(4);
  gpio_set_irq_enabled_with_callback(pinNum, RISING | FALLING, true, isr1);
}

void updateLed()
{
  for (size_t i = 0; i < 2; i++)
  {
    int cc = activeledcolor[i];
    if (cc == red)
    {
      put_pixel(urgb_u32(0xff, 0, 0)); // Red
    }
    else if (cc == green)
    {
      put_pixel(urgb_u32(0, 0xff, 0)); // Green
    }
    else if (cc == blue)
    {
      put_pixel(urgb_u32(0, 0, 0xff)); // Blue
    }
  }
  sleep_us(110);
}

void setLedState()
{
  if (wheel1outstring.find("w1x") == 0)
  {
    activeledcolor[0] = red;
  }
  else if (wheel1outstring.find("w1_") == 0)
  {
    if (retstep1 != 0)
    {
      if (retstep1 == 1)
      {
        activeledcolor[0] = blue;
      }
      else
      {
        activeledcolor[0] = green;
      }
    }
  }

  /***************/
  if (wheel2outstring.find("w2x") == 0)
  {
    activeledcolor[1] = red;
  }
  else if (wheel2outstring.find("w2_") == 0)
  {
    if (retstep2 != 0)
    {
      if (retstep2 == 1)
      {
        activeledcolor[1] = blue;
      }
      else
      {
        activeledcolor[1] = green;
      }
    }
  }

  updateLed();
}

void sendwheelposition()
{
  if (retstep1 != 0)
  {
    if (retstep1 == -1)
    {
      wheel1outstring = "w1x";
    }
    Wheel1_Slot = retstep1;
    string slotnumPadded = "";
    if (Wheel1_Slot < 100 && Wheel1_Slot > 9)
    {
      slotnumPadded += "0";
      slotnumPadded += to_string(Wheel1_Slot);
    }
    else if (Wheel1_Slot < 10)
    {
      slotnumPadded += "00";
      slotnumPadded += to_string(Wheel1_Slot);
    }
    outstr = wheel1outstring + slotnumPadded;
    printf(outstr.c_str());
    retstep1 = 0;
  }

  if (retstep2 != 0)
  {
    if (retstep2 == -1)
    {
      wheel2outstring = "w2x";
    }
    Wheel2_Slot = retstep2;
    string slotnumPadded = "";
    if (Wheel2_Slot < 100 && Wheel2_Slot > 9)
    {
      slotnumPadded += "0";
      slotnumPadded += to_string(Wheel2_Slot);
    }
    else if (Wheel2_Slot < 10)
    {
      slotnumPadded += "00";
      slotnumPadded += to_string(Wheel2_Slot);
    }
    outstr = wheel2outstring + slotnumPadded;
    printf(outstr.c_str());
    retstep2 = 0;
  }
}

void resetwheel1()
{
  int res = wheel1.setToStart();
  //cout << res <<endl;
  if (res == 1)
  {
    Wheel1_Slot = res;
    wheel1outstring = "w1_";
    Wheel1reset = true;
    activeledcolor[0] = blue;
    updateLed();
    outstr = wheel1outstring + "001";
    printf(outstr.c_str());
  }
}
void resetwheel2()
{
  int res = wheel2.setToStart();
  if (res == 1)
  {
    Wheel2_Slot = res;
    wheel2outstring = "w2_";
    Wheel2reset = true;
    activeledcolor[1] = blue;
    updateLed();
    outstr = wheel2outstring + "001";
    printf(outstr.c_str());
  }
}

void caliberateSensors(){
  int res1 = wheel1.CalibrateSensors(1);
  int res2 = wheel1.CalibrateSensors(2);
  int res3 = wheel2.CalibrateSensors(1);
  int res4 = wheel2.CalibrateSensors(2);

  outstr = to_string(res1) +","+ to_string(res2) +","+ to_string(res3) +","+ to_string(res4) +"\n";
  printf(outstr.c_str());
  
}
void connecttoPC(string str)
{
  // reply only when you receive data:
  inString = str;
  outstr = inString;
  //printf(outstr.c_str());
  if (inString != "")
  {
    //SerialUSB.println("     " + inString + "       ");
    if (inString == "p")
    { //connection byte
      inString = "";

      outstr = "ALPnPW300"; //reply with your dial type
      printf(outstr.c_str());
    }
    else if (inString == "rsw1")
    {
      resetwheel1();
      inString = "";
    }
    else if (inString == "rsw2")
    {
      resetwheel2();
      inString = "";
    }
    else if (inString.find("w1=") == 0 && inString.find("xx") < 10)
    {
      //set wheel1 resolution

      inString.replace(inString.find("w1="), 3, "");
      inString.replace(inString.find("xx"), 2, "");
      //cout << "replaced  "<<inString <<endl;
      Wheel1_SlotCount = stoi(inString);
      wheel1.set_encoderResolution(Wheel1_SlotCount);
      if (Wheel1_SlotCount != 72)
      {
        //wheel1.set_bound(80);
        wheel1.invertCount(true);
      }
      else
      {
        //wheel1.set_bound(10);
        wheel1.invertCount(false);
      }
      wheel1outstring = "w1x";
      outstr = wheel1outstring + "001";
      printf(outstr.c_str());
      Wheel1reset = false;
      //SerialUSB.print(inString.toInt());
      inString = "";
      //SerialUSB.print("ack111");
    }
    else if (inString.find("w2=") == 0 && inString.find("xx") < 10)
    {
      //set wheel2 resolution
      inString.replace(inString.find("w2="), 3, "");
      inString.replace(inString.find("xx"), 2, "");
      Wheel2_SlotCount = stoi(inString);
      wheel2.set_encoderResolution(Wheel2_SlotCount);
      if (Wheel2_SlotCount != 36)
      {
        //wheel2.set_bound(38);
        wheel2.invertCount(true);
      }
      else
      {
        //wheel2.set_bound(10);
        wheel2.invertCount(false);
      }

      wheel2outstring = "w2x";
      outstr = wheel2outstring + "001";
      printf(outstr.c_str());
      Wheel2reset = false;
      //SerialUSB.print(inString.toInt());
      inString = "";
      //SerialUSB.print("ack111");
    }
    else if (inString == "cali"){
      caliberateSensors();
      inString = "";
    }
    else if (inString.find("loadcali=") == 0)
    {
      inString.replace(inString.find("loadcali="), 9, "");
      int sval[4] = {0,0,0,0};
      int svalcnt = 0;
      string delimiter = ",";
      size_t pos = 0;
      string token;
      while ((pos = inString.find(delimiter)) != string::npos) {
          token = inString.substr(0, pos);
          sval[svalcnt] = stoi(token);
          svalcnt += 1;
          inString.erase(0, pos + delimiter.length());
      }
      sval[svalcnt] = stoi(inString);
      if (sval[0] != 0 && sval[1] != 0)
      {
        wheel1.LoadCalibrationData(sval[0],sval[1]);
      }
      if (sval[2] != 0 && sval[3] != 0)
      {
        wheel2.LoadCalibrationData(sval[2],sval[3]);
      }
      
      inString = "";
    }
    else
    {
      inString = "";
    }
  }
}

void readtobuffer()
{
  char chr = getchar_timeout_us(0);
  if (chr != 255)
  {
    if (chr == '*')
    {
      dataavailable = true;
    }
    //cout << chr << buffcounter << std::endl;
    if (buffcounter < sizeof(inbuff))
    {
      inbuff[buffcounter] = chr;
      buffcounter += 1;
    }
    else
    {
      buffcounter = 0;
    }
  }
  else
  {
    dataavailable = false;
  }
}

void processinData()
{
  if (dataavailable)
  {
    //cout << inbuff << std::endl;
    int tempcnt = 0;
    while (inbuff[tempcnt] != '*')
    {
      inString += inbuff[tempcnt];
      tempcnt += 1;
    }
    //cout << inString << std::endl;
    connecttoPC(inString);
    buffcounter = 0;
    dataavailable = false;
    memset(inbuff, 0, sizeof(inbuff));
  }
}



int main()
{
  stdio_init_all();
  sleep_ms(500);
  //setinterrupt();

  const uint LED_PIN = PICO_DEFAULT_LED_PIN;
  gpio_init(LED_PIN);
  gpio_set_dir(LED_PIN, GPIO_OUT);

  PIO pio = pio0;
  int sm = 0;
  uint offset = pio_add_program(pio, &ws2812_program);
  //char str[12];

  ws2812_program_init(pio, sm, offset, PIN_TX, 800000, false);

  wheel1.set_haptics(25, 50, 255); //set haptic feedback variables (arduino pwm pin, duration of haptics(ms), pwn strength from 0-255)
  wheel1.set_adcresolution(12);
  wheel1.initialize_encoder();
  wheel2.set_haptics(25, 50, 255); //set haptic feedback variables (arduino pwm pin, duration of haptics(ms), pwn strength from 0-255)
  wheel2.set_adcresolution(12);
  wheel2.initialize_encoder();
  wheel1.set_encoderResolution(Wheel1_SlotCount);
  //wheel1.invertCount(true);
  //wheel1.setToStart();
  wheel2.set_encoderResolution(Wheel2_SlotCount);
  // wheel2.setToStart();
  wheel2.setResistorDivider(10, 1.2, 3.3);
  wheel1.setResistorDivider(10, 1.4, 3.3);

  activeledcolor[0] = blue;
  activeledcolor[1] = blue;
  updateLed();
  sleep_ms(1000);

  activeledcolor[0] = green;
  activeledcolor[1] = green;
  updateLed();
  sleep_ms(1000);

  activeledcolor[0] = red;
  activeledcolor[1] = red;
  updateLed();
  sleep_ms(1000);

  while (true)
  {
    //printf("return %d \n",wheel1.detect_rotation());
    //printf("s1 %d s2 %d \n", wheel1.get_sensorValue(1), wheel1.get_sensorValue(2));
    retstep2 = wheel2.detect_rotation(); // function returns a signed integer based on rotation step detected
    retstep1 = wheel1.detect_rotation(); // function returns a signed integer based on rotation step detected
    setLedState();
    sendwheelposition();
    readtobuffer();
    processinData();
    //printf("s1s %d s1n %d s2s %d s2n %d \n", gpio_get(wheel1.get_sensorINTpin(1)), gpio_get(wheel1.get_sensorINTpin(3)), gpio_get(wheel1.get_sensorINTpin(2)), gpio_get(wheel1.get_sensorINTpin(4)));
    /*
    gpio_put(LED_PIN, 1);
    sleep_ms(100);
    gpio_put(LED_PIN, 0);
    sleep_ms(100);
    */
  }
}
